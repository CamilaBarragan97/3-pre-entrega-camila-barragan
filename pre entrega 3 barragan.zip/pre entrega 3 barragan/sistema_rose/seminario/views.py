from django.shortcuts import render

# Create your views here.
from .models import  seminario


def listar_seminario(request):
    contexto = {
        'seminario': seminario.objects.all()
    }
    http_response = render(
        request=request,
        template_name='seminario/seminario.html',
        context=contexto,
     ) 
    return http_response