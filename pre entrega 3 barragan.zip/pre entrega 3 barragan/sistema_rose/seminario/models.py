from django.db import models

# Create y
class seminario(models.Model):
    nombre_del_educador = models.CharField(max_length=256)
    especialidad_del_educador = models.CharField(max_length=126)
    comision = models.IntegerField()
    fecha_comienzo_seminario = models.DateField(null=True)

def __str__(self):
        return f"{self.nombre_del_educador}, {self.especialidad_del_educador}, {self.fecha_comienzo_seminario}"
