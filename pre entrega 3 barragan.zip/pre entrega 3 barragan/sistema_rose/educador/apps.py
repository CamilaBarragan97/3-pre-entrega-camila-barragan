from django.apps import AppConfig


class EducadorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'educador'
