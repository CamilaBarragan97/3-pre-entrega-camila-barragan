from django.shortcuts import render

# Create your views here

from .models import  educador


def listar_educador(request):
    contexto = {
        'educador': educador.objects.all()
    }
    http_response = render(
        request=request,
        template_name='educador/educador.html',
        context=contexto,
     ) 
    return http_response