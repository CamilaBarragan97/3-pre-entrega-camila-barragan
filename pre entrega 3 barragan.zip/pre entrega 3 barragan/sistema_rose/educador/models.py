from django.db import models

# Create your models here.
class educador(models.Model):
    nombre_del_educador = models.CharField(max_length=256) 
    especialidad_del_educador = models.CharField(max_length=256)
    email = models.EmailField(blank=True)

    def __str__(self):
        return f"{self.nombre_del_educador}, {self.especialidad_del_educador}, {self.email}"
