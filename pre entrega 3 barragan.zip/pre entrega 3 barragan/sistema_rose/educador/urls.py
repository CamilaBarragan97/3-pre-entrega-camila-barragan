from django.contrib import admin
from django.urls import path
from .views import listar_seminario

urlpatterns = [
   path ('seminario/', listar_seminario),
    ]

 