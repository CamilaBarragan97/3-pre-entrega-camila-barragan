
from django.db import models

# Create your models here.
class Cliente(models.Model):
    nombre_del_cliente = models.CharField(max_length=256)
    nombre_del_local = models.CharField(max_length=256)
    email = models.EmailField(blank=True)
    localidad = models.CharField(max_length=256)
    rubro = models.CharField(max_length=256)

    def __str__(self):
        return f"{self.nombre_del_cliente}, {self.nombre_del_local}, {self.email}"



