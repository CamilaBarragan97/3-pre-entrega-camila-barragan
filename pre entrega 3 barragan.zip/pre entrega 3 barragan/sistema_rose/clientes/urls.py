from django.contrib import admin
from django.urls import path
from .views import listar_clientes

urlpatterns = [
    path("clientes/", listar_clientes),
    ]