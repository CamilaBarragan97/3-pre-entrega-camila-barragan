from django.shortcuts import render

from .models import  Cliente


def listar_clientes(request):
    contexto = {
        'clientes': Cliente.objects.all()
    }
    http_response = render(
        request=request,
        template_name='clientes/clientes.html',
        context=contexto,
     ) 
    return http_response
